#include "bgce.h"   /* for access to global server state */
#include "location_cache.h"
#include "server.h" /* for access to global server state */

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/input.h>
#include <linux/kd.h>
#include <math.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <unistd.h>

#define test_bit(bit, array) ((array)[(bit) / 8] & (1 << ((bit) % 8)))
#define INPUT_DIR "/dev/input"

int ctrl_down = 0;
int alt_down = 0;
int shift_down = 0;
int mouse_x;
int mouse_y;

size_t count;
struct pollfd fds[MAX_INPUT_DEVICES];

struct {
	int active;
	struct Client* target;
	int dx;
	int dy;
	/* Sub-pixel residual in 256ths of a world pixel (integer only). */
	int acc_x;
	int acc_y;
	enum {
		DRAG_MOVE,
		DRAG_RESIZE,
		DRAG_PAN
	} type;
} drag;

/* Per-device metadata for absolute pointer scaling */
static struct {
	int is_abs_pointer;
	int abs_x_min, abs_x_max;
	int abs_y_min, abs_y_max;
} dev_info[MAX_INPUT_DEVICES];

extern struct ServerState server;
extern struct config config;

int resize_buffer(struct Client* c, int dx, int dy) {
	char old_name[64];
	size_t buf_size;
	int shm_fd;
	void *map;
	uint32_t new_world_w, new_world_h, new_w, new_h;
	uint32_t old_ww, old_wh;

	if (!c)
		return 0;

	old_ww = c->world_w ? c->world_w : c->width;
	old_wh = c->world_h ? c->world_h : c->height;
	new_world_w = (uint32_t)((int)old_ww + dx);
	new_world_h = (uint32_t)((int)old_wh + dy);
	if (new_world_w == 0 || new_world_h == 0)
		return 0;

	/*
	 * Keep buffer:world ratio so content scale matches creation zoom.
	 * Client is told the new buffer size via MSG_BUFFER_CHANGE.
	 */
	new_w = (uint32_t)((float)new_world_w * (float)c->width / (float)old_ww + 0.5f);
	new_h = (uint32_t)((float)new_world_h * (float)c->height / (float)old_wh + 0.5f);
	if (new_w < 1)
		new_w = 1;
	if (new_h < 1)
		new_h = 1;

	old_name[0] = '\0';
	if (c->buffer) {
		munmap(c->buffer, c->width * c->height * BGCE_BYTES_PER_PIXEL);
		c->buffer = NULL;
		strncpy(old_name, c->shm_name, sizeof(old_name) - 1);
		old_name[sizeof(old_name) - 1] = '\0';
	}

	buf_size = (size_t)new_w * new_h * BGCE_BYTES_PER_PIXEL;
	shm_fd = bgce_buf_create(c->shm_name, sizeof(c->shm_name), buf_size);
	if (shm_fd < 0) {
		perror("[BGCE] create buffer for resize");
		if (old_name[0])
			bgce_buf_unlink(old_name);
		return 0;
	}

	map = mmap(NULL, buf_size, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
	close(shm_fd);
	if (map == MAP_FAILED) {
		perror("[BGCE] mmap for resize");
		bgce_buf_unlink(c->shm_name);
		c->shm_name[0] = '\0';
		if (old_name[0])
			bgce_buf_unlink(old_name);
		return 0;
	}

	if (old_name[0])
		bgce_buf_unlink(old_name);

	c->buffer = map;
	c->width = new_w;
	c->height = new_h;
	c->world_w = new_world_w;
	c->world_h = new_world_h;
	printf("[BGCE] Client resized: %p size=%zu buf=%ux%u world=%ux%u name=%s\n",
	       c->buffer,
	       c->width * c->height * 4UL,
	       c->width, c->height,
	       c->world_w, c->world_h,
	       c->shm_name);
	return 1;
}

/* Pick topmost non-background client under screen-space (x, y). */
struct Client* pick_client(int x, int y) {
	int wx, wy;
	screen_to_world(&server, x, y, &wx, &wy);

	struct Client* c = server.clients;
	struct Client* picked = NULL;
	while (c) {
		uint32_t ww = c->world_w ? c->world_w : c->width;
		uint32_t wh = c->world_h ? c->world_h : c->height;
		if (wx >= (int)c->x && wx < (int)(c->x + ww) &&
		    wy >= (int)c->y && wy < (int)(c->y + wh)) {
			picked = c;
			break;
		}
		c = c->next;
	}
	return (picked && picked->z > 0) ? picked : NULL; /* skip background */
}

/*
 * Screen-pixel mouse delta → integer world delta.
 *   world += mouse * speed * 100 / zoom_pct
 * Residual stored in 256ths of a world pixel.
 * `speed` is only converted from config float at the call boundary.
 */
static void screen_delta_to_world(int sdx, int sdy, float speed,
                                  int *acc_x, int *acc_y,
                                  int *wdx, int *wdy)
{
	int z = server.zoom_pct > 0 ? server.zoom_pct : BGCE_ZOOM_PCT_1X;
	/* speed 1.0 → 256; keep integer after this conversion */
	int sp = (int)(speed * 256.0f + 0.5f);
	if (sp < 1)
		sp = 256;

	/* delta_256 = sdx * sp * 100 / z */
	*acc_x += sdx * sp * 100 / z;
	*acc_y += sdy * sp * 100 / z;
	*wdx = *acc_x / 256;
	*wdy = *acc_y / 256;
	*acc_x -= *wdx * 256;
	*acc_y -= *wdy * 256;
}

static void apply_zoom_at_cursor(int dir)
{
	int old_pct = server.zoom_pct;
	int wx, wy;
	int z;

	/* Keep the world point under the cursor fixed on screen. */
	screen_to_world(&server, mouse_x, mouse_y, &wx, &wy);

	if (!bgce_zoom_step(&server, dir))
		return;

	z = server.zoom_pct > 0 ? server.zoom_pct : BGCE_ZOOM_PCT_1X;
	server.pan_x = wx - mouse_x * 100 / z;
	server.pan_y = wy - mouse_y * 100 / z;
	clamp_viewport(&server);
	redraw_all(&server);
	display_cursor_present();
	printf("[BGCE] Zoom: %d%%  pan=(%d, %d)  was %d%%\n",
	       server.zoom_pct, server.pan_x, server.pan_y, old_pct);
}

void client_disconnected(struct Client* c)
{
	if (!c)
		return;
	if (drag.active && drag.target == c) {
		drag.active = 0;
		drag.target = NULL;
		drag.dx = 0;
		drag.dy = 0;
		drag.acc_x = 0;
		drag.acc_y = 0;
		set_cursor_type(BGCE_CURSOR_DEFAULT);
		printf("[BGCE] Drag cancelled (client disconnected).\n");
	}
}

int init_input(void) {
	count = 0;
	drag.active = 0;
	mouse_x = (int)server.display_w / 2;
	mouse_y = (int)server.display_h / 2;
	if (mouse_x > (int)server.display_w - CURSOR_WIDTH)
		mouse_x = (int)server.display_w - CURSOR_WIDTH;
	if (mouse_y > (int)server.display_h - CURSOR_HEIGHT)
		mouse_y = (int)server.display_h - CURSOR_HEIGHT;
	if (mouse_x < 0) mouse_x = 0;
	if (mouse_y < 0) mouse_y = 0;
	memset(dev_info, 0, sizeof(dev_info));

	printf("[BGCE] Input: scanning %s for devices (max %d slots)\n",
	       INPUT_DIR, MAX_INPUT_DEVICES);

	DIR* dir = opendir(INPUT_DIR);
	if (!dir) {
		fprintf(stderr, "[BGCE] Input: failed to open %s: %s\n",
		        INPUT_DIR, strerror(errno));
		return -1;
	}

	struct dirent* ent;
	while ((ent = readdir(dir)) != NULL && count < MAX_INPUT_DEVICES) {
		if (strncmp(ent->d_name, "event", 5) != 0)
			continue;

		char path[256 + 12];
		snprintf(path, sizeof(path), "%s/%s", INPUT_DIR, ent->d_name);

		int fd = open(path, O_RDONLY | O_CLOEXEC);
		if (fd < 0) {
			fprintf(stderr, "[BGCE] Input: cannot open %s: %s%s\n",
			        path, strerror(errno),
			        (errno == EACCES || errno == EPERM)
			            ? " (try adding your user to the 'input' group)"
			            : "");
			continue;
		}

		/* Device name */
		char name[256] = "Unknown";
		if (ioctl(fd, EVIOCGNAME(sizeof(name)), name) < 0)
			strcpy(name, "Unknown");

		/* Physical topology */
		char phys[256] = "";
		ioctl(fd, EVIOCGPHYS(sizeof(phys)), phys);

		/* Bus / vendor / product / version */
		struct input_id id = {0};
		ioctl(fd, EVIOCGID, &id);

		printf("[BGCE] Input: probing %s \"%s\"\n", path, name);
		printf("[BGCE]   phys: %s\n", phys[0] ? phys : "(none)");
		printf("[BGCE]   bus=0x%04x vendor=0x%04x product=0x%04x version=0x%04x\n",
		       id.bustype, id.vendor, id.product, id.version);

		/* Top-level event types */
		unsigned long ev_bits[(EV_MAX + 7) / 8] = {0};
		if (ioctl(fd, EVIOCGBIT(0, sizeof(ev_bits)), ev_bits) < 0) {
			fprintf(stderr, "[BGCE]   EVIOCGBIT failed: %s — skipping\n",
			        strerror(errno));
			close(fd);
			continue;
		}

		int has_key = test_bit(EV_KEY, ev_bits);
		int has_rel = test_bit(EV_REL, ev_bits);
		int has_abs = test_bit(EV_ABS, ev_bits);

		printf("[BGCE]   event types:%s%s%s%s%s\n",
		       has_key                      ? " KEY" : "",
		       has_rel                      ? " REL" : "",
		       has_abs                      ? " ABS" : "",
		       test_bit(EV_MSC, ev_bits)    ? " MSC" : "",
		       test_bit(EV_SW,  ev_bits)    ? " SW"  : "");

		/* Detailed key/button bits */
		unsigned long key_bits[(KEY_MAX + 7) / 8] = {0};
		if (has_key)
			ioctl(fd, EVIOCGBIT(EV_KEY, sizeof(key_bits)), key_bits);

		int has_mouse_btn = test_bit(BTN_LEFT,   key_bits) ||
		                    test_bit(BTN_RIGHT,  key_bits) ||
		                    test_bit(BTN_MIDDLE, key_bits) ||
		                    test_bit(BTN_MOUSE,  key_bits);
		int has_touch_btn = test_bit(BTN_TOUCH,  key_bits);
		int has_tool_finger = test_bit(BTN_TOOL_FINGER, key_bits);
		int has_kbd_key   = test_bit(KEY_A,     key_bits) ||
		                    test_bit(KEY_B,     key_bits) ||
		                    test_bit(KEY_SPACE, key_bits) ||
		                    test_bit(KEY_ENTER, key_bits) ||
		                    test_bit(KEY_ESC,   key_bits);

		if (has_key)
			printf("[BGCE]   buttons:%s%s%s%s%s%s%s\n",
			       test_bit(BTN_LEFT,   key_bits) ? " BTN_LEFT"   : "",
			       test_bit(BTN_RIGHT,  key_bits) ? " BTN_RIGHT"  : "",
			       test_bit(BTN_MIDDLE, key_bits) ? " BTN_MIDDLE" : "",
			       test_bit(BTN_TOUCH,  key_bits) ? " BTN_TOUCH"  : "",
			       test_bit(BTN_TOOL_FINGER, key_bits) ? " BTN_TOOL_FINGER" : "",
			       has_kbd_key                    ? " [has keyboard keys]" : "",
			       (!has_mouse_btn && !has_touch_btn && !has_kbd_key)
			                                      ? " (none relevant)" : "");

		/* REL sub-capabilities */
		if (has_rel) {
			unsigned long rel_bits[(REL_MAX + 7) / 8] = {0};
			ioctl(fd, EVIOCGBIT(EV_REL, sizeof(rel_bits)), rel_bits);
			printf("[BGCE]   rel axes:%s%s%s%s\n",
			       test_bit(REL_X,     rel_bits) ? " REL_X"     : "",
			       test_bit(REL_Y,     rel_bits) ? " REL_Y"     : "",
			       test_bit(REL_WHEEL, rel_bits) ? " REL_WHEEL" : "",
			       test_bit(REL_HWHEEL,rel_bits) ? " REL_HWHEEL": "");
		}

		/* ABS sub-capabilities and ranges */
		int has_abs_x = 0, has_abs_y = 0;
		struct input_absinfo abs_x_info = {0};
		struct input_absinfo abs_y_info = {0};
		if (has_abs) {
			unsigned long abs_bits[(ABS_MAX + 7) / 8] = {0};
			ioctl(fd, EVIOCGBIT(EV_ABS, sizeof(abs_bits)), abs_bits);
			has_abs_x = test_bit(ABS_X, abs_bits);
			has_abs_y = test_bit(ABS_Y, abs_bits);
			printf("[BGCE]   abs axes:%s%s%s%s%s\n",
			       has_abs_x                           ? " ABS_X"        : "",
			       has_abs_y                           ? " ABS_Y"        : "",
			       test_bit(ABS_MT_POSITION_X, abs_bits) ? " ABS_MT_X"  : "",
			       test_bit(ABS_MT_POSITION_Y, abs_bits) ? " ABS_MT_Y"  : "",
			       test_bit(ABS_PRESSURE, abs_bits)      ? " PRESSURE"  : "");

			if (has_abs_x && ioctl(fd, EVIOCGABS(ABS_X), &abs_x_info) == 0)
				printf("[BGCE]   ABS_X range: %d..%d (res %d)\n",
				       abs_x_info.minimum, abs_x_info.maximum, abs_x_info.resolution);
			if (has_abs_y && ioctl(fd, EVIOCGABS(ABS_Y), &abs_y_info) == 0)
				printf("[BGCE]   ABS_Y range: %d..%d (res %d)\n",
				       abs_y_info.minimum, abs_y_info.maximum, abs_y_info.resolution);
		}

		if (!has_key && !has_rel && !has_abs) {
			printf("[BGCE]   SKIP: no KEY/REL/ABS capabilities\n");
			close(fd);
			continue;
		}

		/* Accept mice, touchpads, abs pointers, keyboards */
		int accept = 0;
		const char* accept_reason = NULL;

		if (has_rel) {
			accept = 1;
			accept_reason = "relative pointer (mouse/trackball)";
		}
		if (has_abs && has_mouse_btn) {
			accept = 1;
			accept_reason = "absolute pointer with mouse buttons (touchpad/tablet)";
		}
		if (has_abs && has_touch_btn && has_abs_x && has_abs_y) {
			accept = 1;
			accept_reason = "touchscreen (BTN_TOUCH + ABS_X/Y)";
		}
		if (has_abs && has_tool_finger && has_abs_x && has_abs_y) {
			accept = 1;
			accept_reason = "touchpad (BTN_TOOL_FINGER + ABS_X/Y)";
		}
		if (has_key && (has_kbd_key || has_mouse_btn)) {
			accept = 1;
			accept_reason = has_kbd_key ? "keyboard" : "button device";
		}

		if (!accept) {
			printf("[BGCE]   SKIP: does not match any known device pattern\n");
			close(fd);
			continue;
		}

		printf("[BGCE]   ACCEPT: %s\n", accept_reason);

		/* Build type_mask */
		uint16_t type_mask = 0;
		if (has_key) type_mask |= (1 << EV_KEY);
		if (has_rel) type_mask |= (1 << EV_REL);
		if (has_abs) type_mask |= (1 << EV_ABS);

		fds[count].fd = fd;
		fds[count].events = POLLIN;

		server.input.devs[count].id = count;
		server.input.devs[count].type_mask = type_mask;
		strncpy(server.input.devs[count].name, name,
		        sizeof(server.input.devs[count].name) - 1);

		/* Store ABS range for absolute pointer scaling */
		if (has_abs && has_abs_x && has_abs_y &&
		    (has_mouse_btn || has_touch_btn || has_tool_finger)) {
			dev_info[count].is_abs_pointer = 1;
			dev_info[count].abs_x_min = abs_x_info.minimum;
			dev_info[count].abs_x_max = abs_x_info.maximum;
			dev_info[count].abs_y_min = abs_y_info.minimum;
			dev_info[count].abs_y_max = abs_y_info.maximum;
			printf("[BGCE]   -> registered as absolute pointer (slot %zu)\n", count);
		}

		count++;
	}

	closedir(dir);

	printf("[BGCE] Input: %zu device(s) accepted\n", count);
	if (count == 0) {
		fprintf(stderr, "[BGCE] Input: WARNING — no suitable input devices found\n");
		fprintf(stderr, "[BGCE] Input:   check permissions (user in 'input' group?)\n");
		fprintf(stderr, "[BGCE] Input:   check that mouse/keyboard is plugged in\n");
		server.input.count = 0;
		return 0;
	}
	server.input.count = count;

	return 0;
}

/*
 * Check if current modifier+key state matches a configured shortcut.
 * Required modifiers on the binding must be held; bare keys (no mods in the
 * binding) only match when no mods are held.
 */
static struct shortcut *match_shortcut(int ctrl, int alt, int shift, uint16_t key) {
	for (int i = 0; i < config.shortcut_count; i++) {
		struct shortcut* sc = &config.shortcuts[i];
		int bare;

		if (sc->combo.key != key)
			continue;
		if (sc->combo.ctrl && !ctrl)
			continue;
		if (sc->combo.alt && !alt)
			continue;
		if (sc->combo.shift && !shift)
			continue;
		bare = !sc->combo.ctrl && !sc->combo.alt && !sc->combo.shift;
		if (bare && (ctrl || alt || shift))
			continue;
		return sc;
	}
	return NULL;
}

/*
 * Keyboard shortcuts are configured via the config file ([shortcuts] section).
 * Built-in behavior for mouse modifiers:
 *  ALT + LEFT_CLICK + DRAG on a client: move window
 *  ALT + RIGHT_CLICK + DRAG on a client: resize window
 *  ALT + LEFT_CLICK + DRAG on empty space: pan the desktop
 *  ALT + SCROLL: zoom in/out (centered on cursor)
 *
 *  Returns if shortcut was handled
 */
static int handle_input_event(struct input_event ev, size_t dev_idx) {
	(void)dev_idx;

	if (ev.type == EV_KEY && (ev.value == 1 || ev.value == 2)) {
		/* value 1 = press, 2 = autorepeat — update mod state on both */
		if (ev.code == KEY_LEFTCTRL || ev.code == KEY_RIGHTCTRL)
			ctrl_down = 1;
		else if (ev.code == KEY_LEFTALT || ev.code == KEY_RIGHTALT)
			alt_down = 1;
		else if (ev.code == KEY_LEFTSHIFT || ev.code == KEY_RIGHTSHIFT)
			shift_down = 1;

		/* Only fire shortcuts on the non-modifier key of the chord. */
		if (ev.code == KEY_LEFTCTRL || ev.code == KEY_RIGHTCTRL ||
		    ev.code == KEY_LEFTALT || ev.code == KEY_RIGHTALT ||
		    ev.code == KEY_LEFTSHIFT || ev.code == KEY_RIGHTSHIFT)
			return 0;

		/* Press only (not autorepeat) for actions */
		if (ev.value != 1)
			return 0;

		struct shortcut *sc =
		        match_shortcut(ctrl_down, alt_down, shift_down, ev.code);
		if (sc) {
			if (sc->type == SHORTCUT_BUILTIN) {
				if (strcmp(sc->value, "exit") == 0) {
					/*
					 * Do not printf to the log pipe here: a full
					 * pipe can block forever so shutdown never
					 * runs.  bgce_request_shutdown announces on
					 * the real console.
					 */
					bgce_request_shutdown();
					return 1; /* not reached */
				} else if (strcmp(sc->value, "screenshot") == 0) {
					if (server.focused_client) {
						printf("[BGCE] Shortcut: screenshot "
						       "skipped (client focused — "
						       "forward key to app)\n");
						return 0;
					}
					printf("[BGCE] Shortcut: builtin screenshot\n");
					take_screenshot("screenshot.png");
					return 1;
				}
				printf("[BGCE] Shortcut: unknown builtin '%s'\n",
				       sc->value);
			} else if (sc->type == SHORTCUT_COMMAND) {
				pid_t pid = fork();
				if (pid == 0) {
					char line[sizeof(sc->value)];
					char *argv[64];
					int argc = 0;
					char *p;
					int devnull;

					/*
					 * Detach from bgce's session/tty so the child is not
					 * a console job (SIGINT / controlling terminal).
					 */
					if (setsid() < 0)
						(void)setpgid(0, 0);
					devnull = open("/dev/null", O_RDWR | O_CLOEXEC);
					if (devnull >= 0) {
						dup2(devnull, STDIN_FILENO);
						dup2(devnull, STDOUT_FILENO);
						dup2(devnull, STDERR_FILENO);
						if (devnull > STDERR_FILENO)
							close(devnull);
					}
					signal(SIGINT, SIG_DFL);
					signal(SIGTERM, SIG_DFL);

					/*
					 * No shell: split on whitespace (optional "quoted"
					 * args) and execvp the binary directly.
					 */
					strncpy(line, sc->value, sizeof(line) - 1);
					line[sizeof(line) - 1] = '\0';
					p = line;
					while (*p && argc < (int)(sizeof(argv) / sizeof(argv[0])) - 1) {
						while (*p == ' ' || *p == '\t')
							p++;
						if (!*p)
							break;
						if (*p == '"') {
							p++;
							argv[argc++] = p;
							while (*p && *p != '"')
								p++;
							if (*p)
								*p++ = '\0';
						} else {
							argv[argc++] = p;
							while (*p && *p != ' ' && *p != '\t')
								p++;
							if (*p)
								*p++ = '\0';
						}
					}
					argv[argc] = NULL;
					if (argc < 1)
						_exit(127);
					execvp(argv[0], argv);
					/* Only reached if exec fails — nowhere to log. */
					_exit(127);
				} else if (pid < 0) {
					perror("[BGCE] fork for shortcut command");
				} else {
					printf("[BGCE] Shortcut: exec pid=%d: %s\n",
					       (int)pid, sc->value);
				}
				return 1;
			}
		}
	}

	if (ev.type == EV_KEY && ev.value == 0) { // Key release
		if (ev.code == KEY_LEFTCTRL || ev.code == KEY_RIGHTCTRL)
			ctrl_down = 0;
		else if (ev.code == KEY_LEFTALT || ev.code == KEY_RIGHTALT)
			alt_down = 0;
		else if (ev.code == KEY_LEFTSHIFT || ev.code == KEY_RIGHTSHIFT)
			shift_down = 0;

		// Stop drag/move/pan on button release
		if ((ev.code == BTN_LEFT || ev.code == BTN_RIGHT) && drag.active) {
			printf("[BGCE] End of drag event.\n");
			set_cursor_type(BGCE_CURSOR_DEFAULT);

			if (drag.type == DRAG_MOVE || drag.type == DRAG_PAN) {
				if (drag.type == DRAG_MOVE && drag.target)
					location_cache_remember_client(drag.target);
				drag.active = 0;
				drag.target = NULL;
				drag.acc_x = 0;
				drag.acc_y = 0;
				return 1;
			}

			/* DRAG_RESIZE */
			struct Client* c = drag.target;
			if (c && resize_buffer(c, drag.dx, drag.dy)) {
				printf("[BGCE] Redrawing dx=%d dy=%d.\n", drag.dx, drag.dy);
				if (drag.dx < 0 || drag.dy < 0) {
					redraw_from_resize(&server, *c, drag.dx, drag.dy);
				}
				draw(&server, *c);

				struct BGCEMessage msg;
				msg.type = MSG_BUFFER_CHANGE;
				struct BufferReply reply = {0};
				strncpy(reply.shm_name, c->shm_name, sizeof(reply.shm_name));
				reply.width = c->width;
				reply.height = c->height;
				msg.data.buffer_reply = reply;
				bgce_send_msg(c->fd, &msg);
			}
			drag.active = 0;
			drag.target = NULL;
			drag.acc_x = 0;
			drag.acc_y = 0;
			return 1;
		}
	}

	if (ev.type == EV_KEY && (ev.code == BTN_LEFT || ev.code == BTN_RIGHT) && ev.value == 1) {
		printf("[BGCE] Click detected at (%d, %d).\n", mouse_x, mouse_y);

		struct Client* c = pick_client(mouse_x, mouse_y);
		struct Client* old_focus = server.focused_client;

		/* Alt + left click on empty space → pan the desktop */
		if (!c && alt_down && ev.code == BTN_LEFT) {
			if (old_focus) {
				struct BGCEMessage lost = {0};
				lost.type = MSG_FOCUS_CHANGE;
				lost.data.focus_event.state = 0;
				bgce_send_msg(old_focus->fd, &lost);
			}
			server.focused_client = NULL;
			drag.active = 1;
			drag.target = NULL;
			drag.type = DRAG_PAN;
			drag.dx = 0;
			drag.dy = 0;
			drag.acc_x = 0;
			drag.acc_y = 0;
			set_cursor_type(BGCE_CURSOR_MOVE);
			printf("[BGCE] Pan desktop started.\n");
			return 1;
		}

		if (!c) {
			if (old_focus) {
				struct BGCEMessage lost = {0};
				lost.type = MSG_FOCUS_CHANGE;
				lost.data.focus_event.state = 0;
				bgce_send_msg(old_focus->fd, &lost);
			}
			server.focused_client = NULL;
			return 0;
		}
		printf("[BGCE] Click detected at client %s z=%d.\n", c->shm_name, c->z);

		// If the clicked client is not already the first, move it
		if (c != server.clients) {
			struct Client* prev = server.clients;
			while (prev && prev->next != c) {
				prev = prev->next;
			}
			if (prev) {
				prev->next = c->next;
				c->next = server.clients;
				server.clients = c;
			}
		}

		if (c != old_focus) {
			if (old_focus) {
				struct BGCEMessage lost = {0};
				lost.type = MSG_FOCUS_CHANGE;
				lost.data.focus_event.state = 0;
				/* Non-blocking send: never stall the input thread. */
				(void)bgce_send_msg(old_focus->fd, &lost);
			}

			/* keep z monotonic (if no previous focus, keep current z) */
			if (old_focus) {
				c->z = old_focus->z + 1;
			}
			server.focused_client = c;

			struct BGCEMessage got = {0};
			got.type = MSG_FOCUS_CHANGE;
			got.data.focus_event.state = 1;
			(void)bgce_send_msg(c->fd, &got);

			/*
			 * Raise only: blit this client on top.  Do not wait for the
			 * app to finish a heavy redraw — that runs on the client
			 * thread when it posts MSG_DRAW.  Never do client work here.
			 */
			draw(&server, *c);
			printf("[BGCE] Client focused (fd=%d).\n", c->fd);
		}

		if (!alt_down) {
			return 0; // Left click
		}

		printf("[BGCE] Alt is pressed, starting move/resize.\n");
		drag.active = 1;
		drag.target = c;
		drag.dx = 0;
		drag.dy = 0;
		drag.acc_x = 0;
		drag.acc_y = 0;

		if (ev.code == BTN_RIGHT) {
			drag.type = DRAG_RESIZE;
			set_cursor_type(BGCE_CURSOR_RESIZE_NWSE);
			printf("[BGCE] Resize event.\n");
		} else {
			drag.type = DRAG_MOVE;
			set_cursor_type(BGCE_CURSOR_MOVE);
			printf("[BGCE] Move event.\n");
		}

		return 1;
	}

	/* Alt + scroll wheel → zoom toward cursor */
	if (ev.type == EV_REL && ev.code == REL_WHEEL && alt_down) {
		/* Positive value = scroll up = zoom in */
		int dir = (ev.value > 0) ? 1 : -1;
		int steps = ev.value >= 0 ? ev.value : -ev.value;
		if (steps < 1)
			steps = 1;
		for (int i = 0; i < steps; i++)
			apply_zoom_at_cursor(dir);
		return 1;
	}

	if (ev.type == EV_REL) {
		int dx = 0;
		int dy = 0;
		switch (ev.code) {
		case REL_X:
			dx += ev.value;
			break;
		case REL_Y:
			dy += ev.value;
			break;
		default:
			/* Wheel without alt, etc. — not a pointer move */
			return 0;
		}
		mouse_x += dx;
		mouse_y += dy;

		// Clamp mouse coordinates to screen boundaries
		{
			int max_x = (int)server.display_w - CURSOR_WIDTH;
			int max_y = (int)server.display_h - CURSOR_HEIGHT;
			if (max_x < 0) max_x = 0;
			if (max_y < 0) max_y = 0;
			if (mouse_x < 0) mouse_x = 0;
			if (mouse_y < 0) mouse_y = 0;
			if (mouse_x > max_x) mouse_x = max_x;
			if (mouse_y > max_y) mouse_y = max_y;
		}

		if (drag.active) {
			switch (drag.type) {
			case DRAG_PAN: {
				int z = server.zoom_pct > 0 ? server.zoom_pct : BGCE_ZOOM_PCT_1X;
				int sp = (int)(config.pan_speed * 256.0f + 0.5f);
				int old_px = server.pan_x;
				int old_py = server.pan_y;
				if (sp < 1)
					sp = 256;
				/* world pan so on-screen speed ≈ mouse * pan_speed */
				server.pan_x -= dx * sp * 100 / (z * 256);
				server.pan_y -= dy * sp * 100 / (z * 256);
				clamp_viewport(&server);
				redraw_pan(&server, old_px, old_py);
				set_cursor_pos(&server, mouse_x, mouse_y);
				break;
			}
			case DRAG_MOVE: {
				struct Client* c = drag.target;
				if (!c)
					return 1;
				int wdx, wdy;
				screen_delta_to_world(dx, dy, config.move_speed,
				                     &drag.acc_x, &drag.acc_y, &wdx, &wdy);
				if (wdx || wdy) {
					redraw_region(&server, c, wdx, wdy);
					c->x = (uint32_t)((int)c->x + wdx);
					c->y = (uint32_t)((int)c->y + wdy);
				}
				set_cursor_pos(&server, mouse_x, mouse_y);
				break;
			}
			case DRAG_RESIZE: {
				int wdx, wdy;
				screen_delta_to_world(dx, dy, config.move_speed,
				                     &drag.acc_x, &drag.acc_y, &wdx, &wdy);
				drag.dx += wdx;
				drag.dy += wdy;
				set_cursor_pos(&server, mouse_x, mouse_y);
				break;
			}
			}
			return 1;
		}

		/* Normal move: update software cursor on every axis event. */
		set_cursor_pos(&server, mouse_x, mouse_y);
		return 0;
	}

	if (ev.type == EV_SYN && ev.code == SYN_REPORT)
		return 0;

	/* Absolute pointer events (touchpads, touchscreens, tablets) */
	if (ev.type == EV_ABS && dev_idx < MAX_INPUT_DEVICES &&
	    dev_info[dev_idx].is_abs_pointer) {
		int old_x = mouse_x;
		int old_y = mouse_y;

		if (ev.code == ABS_X || ev.code == ABS_MT_POSITION_X) {
			int range = dev_info[dev_idx].abs_x_max - dev_info[dev_idx].abs_x_min;
			if (range > 0) {
				mouse_x = (ev.value - dev_info[dev_idx].abs_x_min)
				          * (int)server.display_w / range;
			} else {
				mouse_x = ev.value;
			}
		}
		if (ev.code == ABS_Y || ev.code == ABS_MT_POSITION_Y) {
			int range = dev_info[dev_idx].abs_y_max - dev_info[dev_idx].abs_y_min;
			if (range > 0) {
				mouse_y = (ev.value - dev_info[dev_idx].abs_y_min)
				          * (int)server.display_h / range;
			} else {
				mouse_y = ev.value;
			}
		}

		/* Clamp */
		{
			int max_x = (int)server.display_w - CURSOR_WIDTH;
			int max_y = (int)server.display_h - CURSOR_HEIGHT;
			if (max_x < 0) max_x = 0;
			if (max_y < 0) max_y = 0;
			if (mouse_x < 0) mouse_x = 0;
			if (mouse_y < 0) mouse_y = 0;
			if (mouse_x > max_x) mouse_x = max_x;
			if (mouse_y > max_y) mouse_y = max_y;
		}

		if (drag.active) {
			int dx = mouse_x - old_x;
			int dy = mouse_y - old_y;

			switch (drag.type) {
			case DRAG_PAN: {
				int z = server.zoom_pct > 0 ? server.zoom_pct : BGCE_ZOOM_PCT_1X;
				int sp = (int)(config.pan_speed * 256.0f + 0.5f);
				int old_px = server.pan_x;
				int old_py = server.pan_y;
				if (sp < 1)
					sp = 256;
				server.pan_x -= dx * sp * 100 / (z * 256);
				server.pan_y -= dy * sp * 100 / (z * 256);
				clamp_viewport(&server);
				redraw_pan(&server, old_px, old_py);
				set_cursor_pos(&server, mouse_x, mouse_y);
				break;
			}
			case DRAG_MOVE: {
				struct Client* c = drag.target;
				if (!c)
					return 1;
				int wdx, wdy;
				screen_delta_to_world(dx, dy, config.move_speed,
				                     &drag.acc_x, &drag.acc_y, &wdx, &wdy);
				if (wdx || wdy) {
					redraw_region(&server, c, wdx, wdy);
					c->x = (uint32_t)((int)c->x + wdx);
					c->y = (uint32_t)((int)c->y + wdy);
				}
				set_cursor_pos(&server, mouse_x, mouse_y);
				break;
			}
			case DRAG_RESIZE: {
				int wdx, wdy;
				screen_delta_to_world(dx, dy, config.move_speed,
				                     &drag.acc_x, &drag.acc_y, &wdx, &wdy);
				drag.dx += wdx;
				drag.dy += wdy;
				set_cursor_pos(&server, mouse_x, mouse_y);
				break;
			}
			}
			return 1;
		}

		set_cursor_pos(&server, mouse_x, mouse_y);
		return 0;
	}

	// This means nothing was handled
	return 0;
}

/*
 * Tty Ctrl+C → SIGINT on the process group.  We only swallow it so the
 * compositor does not exit.  Clients get Ctrl+C solely from /dev/input
 * (keys to the focused client).  Synthesizing a chord here double-fired.
 */
void deliver_interrupt_to_focus(void)
{
	/* No-op for clients; retained for API stability. */
}

static void poll_sigint(void)
{
	if (!bgce_sigint_pending)
		return;
	bgce_sigint_pending = 0;
}

void* input_loop(void* arg) {
	(void)arg;

	if (count == 0) {
		printf("[BGCE] Input: no devices, input thread parked\n");
		while (1) {
			poll_sigint();
			sleep(1);
		}
		return NULL;
	}

	printf("[BGCE] Input: polling %zu device(s)\n", count);

	while (1) {
		/*
		 * Finite timeout: SIGINT handling + re-present software cursor
		 * after client redraws (compositor sets dirty, input paints).
		 */
		int timeout_ms = display_cursor_pending() ? 8 : 200;
		int ret = poll(fds, count, timeout_ms);
		poll_sigint();
		/* Always ok to call; no-op if cursor is already valid. */
		display_cursor_present();
		if (ret < 0) {
			if (errno == EINTR)
				continue;
			fprintf(stderr, "[BGCE] Input: poll error: %s\n", strerror(errno));
			break;
		}
		if (ret == 0)
			continue;

		for (size_t i = 0; i < count; i++) {
			if (fds[i].revents & (POLLHUP | POLLERR)) {
				fprintf(stderr, "[BGCE] Input: device slot %zu (\"%s\") disconnected or error\n",
				        i, server.input.devs[i].name);
				close(fds[i].fd);
				fds[i].fd = -1;
				fds[i].events = 0;
				continue;
			}

			if (!(fds[i].revents & POLLIN))
				continue;

			struct input_event ev;
			ssize_t n = read(fds[i].fd, &ev, sizeof(ev));
			if (n == -1) {
				if (errno == EAGAIN || errno == EWOULDBLOCK)
					continue;
				fprintf(stderr, "[BGCE] Input: read error on slot %zu: %s\n",
				        i, strerror(errno));
				continue;
			}
			if (n != sizeof(ev))
				continue;

			if (handle_input_event(ev, (int)i))
				continue;

			if (!server.focused_client)
				continue;
			if (ev.type == EV_SYN)
				continue;

			struct Client c = *server.focused_client;
			struct InputEvent e = {0};
			e.type = ev.type;
			e.device = server.input.devs[i];
			e.code = ev.code;
			e.value = ev.value;

			switch (ev.type) {
			case EV_KEY:
				if (ev.code != BTN_LEFT && ev.code != BTN_RIGHT)
					break;
				/* fall through — mouse buttons carry position */
			case EV_REL:
			case EV_ABS: {
				int wx, wy;
				uint32_t ww = c.world_w ? c.world_w : c.width;
				uint32_t wh = c.world_h ? c.world_h : c.height;
				screen_to_world(&server, mouse_x, mouse_y, &wx, &wy);
				int in = wx >= (int)c.x &&
				         wx < (int)(c.x + ww) &&
				         wy >= (int)c.y &&
				         wy < (int)(c.y + wh);
				if (!in)
					continue;
				if (ww > 0 && wh > 0) {
					e.x = (int32_t)((wx - (int)c.x) *
					                (int)c.width / (int)ww);
					e.y = (int32_t)((wy - (int)c.y) *
					                (int)c.height / (int)wh);
				} else {
					e.x = (int32_t)(wx - (int)c.x);
					e.y = (int32_t)(wy - (int)c.y);
				}
				break;
			}
			default:
				continue;
			}

			struct BGCEMessage msg;
			msg.type = MSG_INPUT_EVENT;
			msg.data.input_event = e;
			/* Drop if the client is not reading (busy); keep the cursor live. */
			(void)bgce_send_msg(c.fd, &msg);
		}
	}
	return NULL;
}
